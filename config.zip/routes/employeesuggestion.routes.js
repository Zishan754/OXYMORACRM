// const express = require("express");
// const router = express.Router();
// const controller = require("../controllers/employeesuggestions.controllers");
// const upload = require("../middlewares/uploadFile"); //  correct path

// router.post("/add-suggestion", upload.single("file"), controller.addSuggestion);

// module.exports = router;
